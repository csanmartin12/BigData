
$f = 'C:\Bases\entrega2\salidas\benchmark\completa\monitor.csv'; $latido = 'C:\Bases\entrega2\salidas\benchmark\completa\latido'; $fin = 'C:\Bases\entrega2\salidas\benchmark\completa\detener'
$k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes'
while (-not (Test-Path $fin)) {
  if ((Test-Path $latido) -and (((Get-Date) - (Get-Item $latido).LastWriteTime).TotalMinutes -gt 15)) { break }
  try {
    $p = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'"
    $b = Get-CimInstance Win32_Battery | Select-Object -First 1
    $m = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
    $ac = (Get-ItemProperty $k).ActiveOverlayAcPowerScheme
    $t = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
    $linea = '{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}' -f $t, $p.ProcessorFrequency, $p.PercentProcessorPerformance, $p.PercentProcessorTime, $b.BatteryStatus, $b.EstimatedChargeRemaining, $ac, $m.AvailableMBytes
    Add-Content -Path $f -Value $linea -Encoding ascii
  } catch { }
  Start-Sleep -Seconds 15
}
